package com.org.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.org.bean.Employee;
import com.org.service.IEmployeeService;

@RestController
public class HomeController {
	@Autowired
	IEmployeeService empServ;
	@RequestMapping(value="/welcome", method=RequestMethod.GET, produces="application/json")
	public String helloPage() {
		return "Hello";
	}
	
	@RequestMapping(value="/getEmployee/{id}", method=RequestMethod.GET, produces="application/json")
	public Employee getEmployee(@PathVariable int id) {
		Employee emp = new Employee();
		emp = empServ.findEmployee(id);
		return emp;
	}
	
	@RequestMapping(value="/addEmployee", method=RequestMethod.POST, consumes="application/json", produces="application/json")
	public Employee addEmployee(@RequestBody Employee employee) {
		employee = empServ.addEmployee(employee);
		return employee;
	}
	
	@RequestMapping(value="/updateEmployee", method=RequestMethod.POST, consumes="application/json", produces="application/json")
	public Employee updateEmployee(@RequestBody Employee employee) {
		 employee = empServ.updateEmployee(employee);
		return employee;
	}
	
	@RequestMapping(value="/getAllEmployees", method=RequestMethod.GET, produces="application/json")
	public List<Employee> getAllEmployees() {
		List<Employee> list = empServ.getEmployeeList();
		return list;
	}
	
	@RequestMapping(value="/deleteEmployee/{id}", method=RequestMethod.POST, consumes="application/json", produces="application/json")
	public Employee deleteEmployee(@PathVariable int id) {
		Employee employee = empServ.deleteEmployee(id);
		return employee;
	}
}