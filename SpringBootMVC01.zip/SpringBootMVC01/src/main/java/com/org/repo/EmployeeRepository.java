package com.org.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.org.bean.Employee;
@Repository
public class EmployeeRepository implements IEmployeeRepository {
	
	
	@PersistenceContext
	private EntityManager em;

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

	@Override
	public Employee save(Employee emp) {
		em.merge(emp);
//		em.getTransaction().commit();
		return emp;
	}
	
	@Override
	public Employee findById(int id) {
		Employee emp = em.find(Employee.class, id);
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		em.merge(emp);
//		em.getTransaction().commit();
		return emp;
	}

	@Override
	public List<Employee> findAll(){
		TypedQuery<Employee> query = em.createQuery("select employee from Employee employee", Employee.class);
		List<Employee> list = query.getResultList();
		return list;
	}

	@Override
	public Employee remove(int id) {
		Employee emp = em.find(Employee.class, id);
		em.remove(emp);
		em.flush();
		return emp;
	}
	
	
}
