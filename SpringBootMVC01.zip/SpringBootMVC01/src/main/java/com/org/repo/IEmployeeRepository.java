package com.org.repo;

import java.util.List;

import com.org.bean.Employee;

public interface IEmployeeRepository {

	Employee save(Employee emp);

	Employee findById(int id);

	Employee updateEmployee(Employee emp);

	List<Employee> findAll();

	Employee remove(int id);

}