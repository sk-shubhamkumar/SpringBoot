package com.org.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.org.bean.Employee;
@Service
public interface IEmployeeService {

	Employee addEmployee(Employee emp);

	Employee findEmployee(int id);

	Employee updateEmployee(Employee emp);

	List<Employee> getEmployeeList();

	Employee deleteEmployee(int id);

}