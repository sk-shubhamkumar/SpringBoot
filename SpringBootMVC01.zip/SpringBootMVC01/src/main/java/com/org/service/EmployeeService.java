package com.org.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.bean.Employee;
import com.org.repo.IEmployeeRepository;


@Service("service")
@Transactional
public class EmployeeService implements IEmployeeService {

	@Autowired
	IEmployeeRepository repo;

	public IEmployeeRepository getRepo() {
		return repo;
	}

	public void setRepo(IEmployeeRepository repo) {
		this.repo = repo;
	}

	@Override
	public Employee addEmployee(Employee emp) {
		return repo.save(emp);
	}

	@Override
	public Employee findEmployee(int id) {
		return repo.findById(id);
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		return repo.save(emp);
	}
	
	@Override
	public List<Employee> getEmployeeList(){
		return repo.findAll();
	}

	@Override
	public Employee deleteEmployee(int id) {
		return repo.remove(id);
	}
}
