package com.org.SpringMVCBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.org")
@EntityScan("com.org.bean")
public class SprintMvcBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprintMvcBootApplication.class, args);
	}

}
